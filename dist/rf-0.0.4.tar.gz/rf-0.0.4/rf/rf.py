print("Hello universe")
