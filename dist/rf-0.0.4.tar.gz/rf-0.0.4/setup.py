from setuptools import find_packages, setup

setup(
    name = "rf",
    packages = ['rf'],
    version = "0.0.4",
    description = "Python package for Reconciliation Framework",
    url="https://github.com/exocube-inc/Reconciliation-Framework-Package",
    author = "Exocube"
    )