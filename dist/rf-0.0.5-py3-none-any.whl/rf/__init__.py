from .rf import dataquality
print("Package running successfully")
