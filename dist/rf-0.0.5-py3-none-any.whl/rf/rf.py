print("Hello universe")

class dataquality: 
    print("class calling")
